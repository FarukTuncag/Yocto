#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>

#define PACKET_SIZE 4096

const char* MESSAGE = "faruktuncag1999";

// Checksum hesaplama fonksiyonu
unsigned short checksum(void *b, int len) {
    unsigned short *buf = (unsigned short *)b;
    unsigned int sum = 0;
    unsigned short result;

    for (sum = 0; len > 1; len -= 2)
        sum += *buf++;

    if (len == 1)
        sum += *(unsigned char *)buf;

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    result = ~sum;

    return result;
}

// Pseudo header struct for TCP checksum calculation
struct pseudo_header {
    u_int32_t source_address;
    u_int32_t dest_address;
    u_int8_t placeholder;
    u_int8_t protocol;
    u_int16_t tcp_length;
};

int main() {
    char ip_address[16];
    printf("Enter the destination IP address: ");
    fgets(ip_address, 16, stdin);
    ip_address[strlen(ip_address) - 1] = '\0'; // Remove the newline character

    // Raw socket oluşturma
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (sock < 0) {
        perror("Failed to create raw socket");
        return 1;
    }

    // IP ve TCP başlıklarıyla birlikte paket oluşturma
    char packet[PACKET_SIZE];
    memset(packet, 0, PACKET_SIZE);

    // IP başlığı
    struct iphdr *iph = (struct iphdr *)packet;
    // TCP başlığı
    struct tcphdr *tcph = (struct tcphdr *)(packet + sizeof(struct iphdr));
    // Hedef adresi
    struct sockaddr_in sin;

    // IP başlığı ayarları
    iph->ihl = 5;
    iph->version = 4;
    iph->tos = 0;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + strlen(MESSAGE));
    iph->id = htonl(54321);
    iph->frag_off = 0;
    iph->ttl = 255;
    iph->protocol = IPPROTO_TCP;
    iph->check = 0; // Checksum daha sonra hesaplanacak
    iph->saddr = inet_addr("192.168.1.31"); // Kaynak IP
    iph->daddr = inet_addr(ip_address); // Hedef IP

    // TCP başlığı ayarları
    tcph->source = htons(12345); // Kaynak port
    tcph->dest = htons(9090); // Hedef port
    tcph->seq = 0;
    tcph->ack_seq = 0;
    tcph->doff = 5; // TCP başlık boyutu
    tcph->fin = 0;
    tcph->syn = 1;
    tcph->rst = 0;
    tcph->psh = 0;
    tcph->ack = 0;
    tcph->urg = 0;
    tcph->window = htons(5840); // TCP pencere boyutu
    tcph->check = 0; // Checksum daha sonra hesaplanacak
    tcph->urg_ptr = 0;

    // Pseudo header ile birlikte TCP checksum hesaplama
    struct pseudo_header psh;
    psh.source_address = inet_addr("192.168.1.31");
    psh.dest_address = inet_addr(ip_address);
    psh.placeholder = 0;
    psh.protocol = IPPROTO_TCP;
    psh.tcp_length = htons(sizeof(struct tcphdr) + strlen(MESSAGE));

    int psize = sizeof(struct pseudo_header) + sizeof(struct tcphdr) + strlen(MESSAGE);
    char *pseudogram = (char *)malloc(psize);

    memcpy(pseudogram, (char *)&psh, sizeof(struct pseudo_header));
    memcpy(pseudogram + sizeof(struct pseudo_header), tcph, sizeof(struct tcphdr));
    memcpy(pseudogram + sizeof(struct pseudo_header) + sizeof(struct tcphdr), MESSAGE, strlen(MESSAGE));

    tcph->check = checksum(pseudogram, psize);

    // IP checksum hesaplama
    iph->check = checksum((unsigned short *)packet, sizeof(struct iphdr));

    // Hedef adresi ayarla
    sin.sin_family = AF_INET;
    sin.sin_port = htons(9090);
    sin.sin_addr.s_addr = inet_addr(ip_address);

    // Mesajı TCP yüküne ekle
    memcpy(packet + sizeof(struct iphdr) + sizeof(struct tcphdr), MESSAGE, strlen(MESSAGE));

    // Paketi gönder
    if (sendto(sock, packet, ntohs(iph->tot_len), 0, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
        perror("Failed to send packet");
        close(sock);
        free(pseudogram);
        return 1;
    }

    printf("Packet sent successfully.\n");

    // Mesaj alma kısmı
    char buffer[PACKET_SIZE];
    while (1) {
        // Paket almak için buffer kullan
        ssize_t data_size = recv(sock, buffer, PACKET_SIZE, 0);
        if (data_size < 0) {
            perror("Failed to receive packet");
            close(sock);
            free(pseudogram);
            return 1;
        }

        // IP başlığını çözümle
        struct iphdr *received_iph = (struct iphdr *)buffer;

        char requested_ip[16];
        printf("Enter the requested IP address: ");
        fgets(requested_ip, 16, stdin);
        requested_ip[strlen(requested_ip) - 1] = '\0'; // Remove the newline character

        if (strcmp(inet_ntoa(*(struct in_addr *)&received_iph->saddr), requested_ip) != 0) {
            // Mesajı atla ve tekrar paket beklemeye devam et
            printf("Received data from unauthorized source: %s\n", inet_ntoa(*(struct in_addr*)&received_iph->saddr));
            continue;
        }

        // TCP yükünü ayır ve ekrana yazdır
        char *data = 20+buffer + sizeof(struct iphdr) + sizeof(struct tcphdr);
        int data_len = data_size - sizeof(struct iphdr) - sizeof(struct tcphdr);
        printf("Received message: %.*s\n", (data_len - 20), data); // 20 byte TCP başlık boyutu
    }

    return 0;
}

